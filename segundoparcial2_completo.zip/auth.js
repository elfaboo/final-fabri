const firebaseConfig = {
  apiKey: "AIzaSyAS7a5mV9As2GfbuzI4MIRp6Zv1itYDUBg",
  authDomain: "pwa-notificaciones-fabri.firebaseapp.com",
  projectId: "pwa-notificaciones-fabri",
  storageBucket: "pwa-notificaciones-fabri.firebasestorage.app",
  messagingSenderId: "140521245389",
  appId: "1:140521245389:web:a263c7b9c9d0ed07443784"
};

const app = initializeApp(firebaseConfig);
const auth = firebase.auth();

function loginEmailPassword(email, password) {
  return auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      localStorage.setItem("userEmail", userCredential.user.email);
      alert("Sesión iniciada");
      location.reload();
    })
    .catch((error) => {
      alert("Error: " + error.message);
    });
}

function loginWithGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider)
    .then((result) => {
      localStorage.setItem("userEmail", result.user.email);
      alert("Sesión iniciada con Google");
      location.reload();
    })
    .catch((error) => {
      alert("Error: " + error.message);
    });
}

function logout() {
  auth.signOut().then(() => {
    localStorage.removeItem("userEmail");
    alert("Sesión cerrada");
    location.reload();
  });
}

function checkAuth() {
  const userEmail = localStorage.getItem("userEmail");
  if (!userEmail) {
    alert("Debes iniciar sesión para enviar encuestas o comentarios.");
    window.location.href = "login.html"; // o reemplaza por un modal
  }
}